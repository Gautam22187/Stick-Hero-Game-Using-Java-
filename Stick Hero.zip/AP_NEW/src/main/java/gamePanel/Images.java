package gamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class Images {
    public static Image background;
    public static Image startButton;
    public static Image hero;
    public static Image hero1;
    public static Image hero2;
    public static Image hero3;
    public static Image hero4;
    public static Image replay;
    public static Image fruit;
    public static Image GameOverScorePanel;
    public static Image home;
    public static final int BACKGROUND_WIDTH = 500;
    public static final int BACKGROUND_HEIGHT = 600;
    public static final int MARIO_WIDTH = 25;
    public static final int MARIO_HEIGHT = 27;

    static {
        try {
            background = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/background/back2.png"));
            startButton = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/play.png"));
            hero = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/hero.png"));
            hero1 = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/hero1.png"));
            hero2 = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/hero2.png"));
            hero3 = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/hero3.png"));
            hero4 = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/hero4.png"));
            fruit = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/fruit.png"));
            GameOverScorePanel = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/scorescreen/scoreplate.png"));
            home = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/scorescreen/home.png"));
            replay = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/scorescreen/replay.png"));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

