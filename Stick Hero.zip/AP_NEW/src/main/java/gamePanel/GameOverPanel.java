package gamePanel;

import gameController.GameController;
import gameEngine.GameEngine;
import javax.swing.*;
//import javafx.util.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class GameOverPanel extends JPanel {
    private GameEngine engine;
    private JButton replayButton;
    private JButton homeButton;

    public GameOverPanel(final GameEngine engine, final GameController controller) {
        this.setLayout(null);
        this.engine = engine;

        replayButton = new JButton("Replay");
        replayButton.addActionListener(new ReplayButtonListener(controller));
        replayButton.setBounds(Images.BACKGROUND_WIDTH / 2 - 240, Images.BACKGROUND_HEIGHT / 2 + 100, 200, 120);

        Font customFont = loadCustomFont("C:\\JAVA\\AP_PROJECT2\\AP_#3new\\this one\\Stick-Hero-master\\Fonts\\southern-aire\\SouthernAire_Personal_Use_Only.ttf");
        replayButton.setFont(customFont);
        add(replayButton);

        homeButton = new JButton("Home");
        homeButton.addActionListener(new HomeButtonListener(controller));
        homeButton.setBounds(Images.BACKGROUND_WIDTH / 2 + 40, Images.BACKGROUND_HEIGHT / 2 + 100, 200, 120);
        homeButton.setFont(customFont);
        add(homeButton);

        setPreferredSize(new Dimension(Images.BACKGROUND_WIDTH, Images.BACKGROUND_HEIGHT));
    }

    private Font loadCustomFont(String fontPath) {
        try {
            Font customFont = Font.createFont(Font.TRUETYPE_FONT, new File(fontPath));
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(customFont);

            return customFont.deriveFont(Font.PLAIN, 35);
        } catch (IOException | FontFormatException e) {
            e.printStackTrace();
            return new Font("Arial", Font.BOLD, 35);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;

        g2d.drawImage(Images.background, -450, 0, null);
        Font customFont = loadCustomFont("C:\\JAVA\\AP_PROJECT2\\AP_#3new\\this one\\Stick-Hero-master\\Fonts\\you-murderer\\youmurdererbb_reg.ttf");
        g2d.setFont(customFont.deriveFont(Font.PLAIN, 130));
        g2d.setColor(Color.RED);
        g2d.drawString("GAME OVER", 35, 120);
        g2d.setFont(new Font("Comic Sans MS", Font.PLAIN, 60));
        g2d.setColor(Color.darkGray);
        g2d.drawString("SCORE: " + engine.getScore(), 130, 250);
        g2d.drawString("FRUIT: " + engine.getfruitNum(), 130, 330);
    }

    private class ReplayButtonListener implements ActionListener {
        private final GameController controller;

        public ReplayButtonListener(GameController controller) {
            this.controller = controller;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.replay();
        }
    }

    private class HomeButtonListener implements ActionListener {
        private final GameController controller;

        public HomeButtonListener(GameController controller) {
            this.controller = controller;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            controller.goToGame();
        }
    }
}
