package gamePanel;

import gameController.GameController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StartPanel extends JPanel {
    private GameController controller;
    private JButton startButton;
    private JToggleButton soundButton;

    public StartPanel(GameController controller) {
        this.controller = controller;
        this.setLayout(null);

        startButton = new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.drawImage(Images.startButton, 0, 0, this.getWidth(), this.getHeight(), this);
            }
        };

        startButton.addActionListener(controller);
        startButton.setBounds(Images.BACKGROUND_WIDTH / 2 - 75, Images.BACKGROUND_HEIGHT / 2 + 25, 150, 150);
        add(startButton);

        soundButton = new JToggleButton("Sound ON");
        soundButton.setBounds(Images.BACKGROUND_WIDTH / 2 - 60, Images.BACKGROUND_HEIGHT / 2 + 200, 120, 40);
        soundButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (soundButton.isSelected()) {
                    // Sound is ON
                    controller.enableSound();
                    soundButton.setText("Sound ON");
                } else {
                    // Sound is OFF
                    controller.disableSound();
                    soundButton.setText("Sound OFF");
                }
            }
        });
        add(soundButton);

        setPreferredSize(new Dimension(Images.BACKGROUND_WIDTH, Images.BACKGROUND_HEIGHT));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;

        g2d.drawImage(Images.background, -450, 0, null);
        g2d.setFont(new Font("Trattatello", Font.BOLD, 100));
        g2d.setColor(Color.darkGray);
        g2d.drawString("STICK", 125, 120);
        g2d.drawString("HERO", 130, 200);
    }
}
