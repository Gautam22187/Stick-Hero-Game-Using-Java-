package gamePanel;

import gameController.GameController;
import gameEngine.GameEngine;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.io.IOException;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.*;

public class PlayPanel extends JPanel {
    private static final int STICK_WIDTH = 3;
    private static final int RECT_HEIGHT = 220;
    private static final int RECT_START = 50;

    private GameEngine engine;
    private GameController controller;

    private int BGMV = 0;

    private int firstWidth;
    private int secondWidth;
    private int secondRectPos;
    private int moveValue;

    private int rotateDegree;
    private int rotateSpeed;

    private int dest;
    private int heroX;
    private int heroY;
    private int imageCycle;
    private int cycleCnt;

    private boolean isfruitEaten;

    private JToggleButton soundButton;

    private class SoundButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (soundButton.isSelected()) {
                // Sound is ON
                controller.enableSound();
                soundButton.setText("Sound ON");
            } else {
                // Sound is OFF
                controller.disableSound();
                soundButton.setText("Sound OFF");
            }
        }
    }

    private class StickDrawer {
        public void drawStick(Graphics2D g2d) {
            calcDegree();
            AffineTransform old = g2d.getTransform();
            g2d.rotate(Math.toRadians(rotateDegree), RECT_START + firstWidth - STICK_WIDTH - 2, Images.BACKGROUND_HEIGHT - RECT_HEIGHT);
            g2d.setColor(Color.BLACK);
            g2d.fillRect(RECT_START + firstWidth - STICK_WIDTH - 2, Images.BACKGROUND_HEIGHT - RECT_HEIGHT - engine.getStickLength(),
                    STICK_WIDTH, engine.getStickLength());
            g2d.setTransform(old);
        }
    }

    private class HeroDrawer {
        public void drawHero(Graphics2D g2d) {
            if (heroX <= RECT_START + firstWidth)
                controller.upsideDown = false;
            AffineTransform old = g2d.getTransform();
            g2d.translate(heroX, heroY + Images.MARIO_HEIGHT);
            if (engine.isMoving() && controller.isUpsideDown()) {
                g2d.scale(1, -1);
            }
            if (rotateDegree == 90 && heroX < dest) {
                switch (imageCycle) {
                    case 0:
                        g2d.drawImage(Images.hero1, 0, -Images.MARIO_HEIGHT, null);
                        break;
                    case 1:
                        g2d.drawImage(Images.hero2, 0, -Images.MARIO_HEIGHT, null);
                        break;
                    case 2:
                        g2d.drawImage(Images.hero3, 0, -Images.MARIO_HEIGHT, null);
                        break;
                    case 3:
                        g2d.drawImage(Images.hero4, 0, -Images.MARIO_HEIGHT, null);
                        break;
                }

                cycleCnt++;
                cycleCnt %= 8;
                if (cycleCnt % 8 == 0) {
                    imageCycle++;
                    imageCycle %= 4;
                }
            } else {
                g2d.drawImage(Images.hero, 0, -Images.MARIO_HEIGHT, null);
            }
            g2d.setTransform(old);
        }
    }

    private StickDrawer stickDrawer = new StickDrawer();
    private HeroDrawer heroDrawer = new HeroDrawer();

    public PlayPanel(GameEngine engine, GameController controller) {
        this.engine = engine;
        this.controller = controller;
        init();

        soundButton = new JToggleButton("Sound ON");
        soundButton.setBounds(20, getHeight() - 60, 120, 40);
        soundButton.addActionListener(new SoundButtonListener());
        add(soundButton);
    }

    public void init() {
        BGMV++;
        moveValue = 0;
        secondRectPos = 600;

        rotateDegree = 0;
        rotateSpeed = 1;

        firstWidth = engine.getFirstRect().getWidth();
        secondWidth = engine.getSecondRect().getWidth();

        heroX = RECT_START + firstWidth - 5 - Images.MARIO_WIDTH;
        heroY = Images.BACKGROUND_HEIGHT - RECT_HEIGHT - Images.MARIO_HEIGHT;

        imageCycle = 0;
        cycleCnt = 0;
        dest = 0;

        isfruitEaten = false;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;

        moveBackground(g2d);

        g2d.setColor(Color.black);

        AffineTransform def = g2d.getTransform();

        calcRectMove();
        drawRects(g2d);

        stickDrawer.drawStick(g2d);

        calcDest();
        moveMario();
        heroDrawer.drawHero(g2d);

        checkForfruitEaten();
        drawfruit(g2d);

        g2d.setTransform(def);

        checkForGameOver();

        drawScore(g2d);
    }

    private void calcRectMove() {
        if (moveValue >= engine.getDistance() + firstWidth) {
            controller.nextRect(isfruitEaten);
            init();
        }

        if (rotateDegree == 90 && heroX == dest && !engine.isGameOver()) {
            moveValue += 4;
        }
    }

    private void moveBackground(Graphics2D g2d) {
        if (rotateDegree == 90 && heroX == dest && BGMV % 20 != 0 && !engine.isGameOver())
            BGMV++;

        AffineTransform old = g2d.getTransform();
        g2d.translate(-BGMV, 0);
        g2d.drawImage(Images.background, 0, 0, null);
        g2d.setTransform(old);
    }

    private void calcDegree() {
        if (!engine.isMoving())
            return;

        if (rotateDegree < 90) {
            rotateDegree += rotateSpeed / 5;
            rotateSpeed++;
        } else {
            rotateDegree = 90;
        }
    }

    private void calcDest() {
        if (engine.isGameOver() && controller.isUpsideDown())
            return;

        if (engine.isGameOver()) {
            dest = RECT_START + firstWidth - Images.MARIO_WIDTH + engine.getStickLength();
        } else {
            dest = RECT_START + firstWidth + engine.getDistance() + secondWidth - 5 - Images.MARIO_WIDTH;
        }
    }

    private void moveMario() {
        if (rotateDegree == 90 && heroX < dest)
            heroX += 2;

        if (heroX > dest)
            heroX = dest;

        if (heroX == dest && engine.isGameOver())
            heroY += 20;

        if (heroY > Images.BACKGROUND_HEIGHT)
            controller.gameOver();
    }

    private void drawfruit(Graphics2D g2d) {
        if (!isfruitEaten) {
            try {
                Image mushroomImage = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/fruit.png"));

                g2d.drawImage(mushroomImage, RECT_START + firstWidth + engine.getfruitPos(), Images.BACKGROUND_HEIGHT - RECT_HEIGHT + 5, null);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void checkForfruitEaten() {
        if (controller.isUpsideDown() && heroX + Images.MARIO_WIDTH >= RECT_START + firstWidth + engine.getfruitPos()
                && heroX <= RECT_START + firstWidth + engine.getfruitPos() + 25) {
            isfruitEaten = true;
            controller.playEatSound();
        }
    }

    private void checkForGameOver() {
        if (controller.isUpsideDown() && heroX + Images.MARIO_WIDTH >= RECT_START + firstWidth + engine.getDistance()) {
            int redSpotMinX = RECT_START + firstWidth + engine.getDistance() - secondWidth / 2;
            int redSpotMaxX = RECT_START + firstWidth + engine.getDistance() + secondWidth / 2;

            if (heroX + Images.MARIO_WIDTH >= redSpotMinX && heroX <= redSpotMaxX) {
                engine.nextRectangle();
            } else {
                engine.setGameOver(true);
                dest = heroX;
            }
        }
    }

    private void drawScore(Graphics2D g2d) {
        g2d.setFont(new Font("Trattatello", Font.PLAIN, 35));
        g2d.setColor(Color.black);
        g2d.drawString("Score : " + engine.getTotalScore(), 30, 70);

        try {
            Image fruitImage = ImageIO.read(new File("C:/JAVA/AP_PROJECT2/AP_#3new/this one/Stick-Hero-master/images/fruit.png"));
            g2d.drawImage(fruitImage, 350, 50, null);
            g2d.drawString("" + engine.getfruitNum(), 420, 70); // Adjusted position for the fruit count
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void drawRects(Graphics2D g2d) {
        g2d.translate(-moveValue, 0);

        g2d.setColor(Color.BLACK);
        g2d.fillRect(RECT_START, Images.BACKGROUND_HEIGHT - RECT_HEIGHT, firstWidth, RECT_HEIGHT);

        drawRedDot(g2d, RECT_START + firstWidth / 2, Images.BACKGROUND_HEIGHT - RECT_HEIGHT);

        if (!engine.isMoving() && rotateDegree == 0 && secondRectPos != RECT_START + firstWidth + engine.getDistance())
            secondRectPos -= 20;
        if (secondRectPos < RECT_START + firstWidth + engine.getDistance())
            secondRectPos = RECT_START + firstWidth + engine.getDistance();

        g2d.setColor(Color.BLACK);
        g2d.fillRect(secondRectPos, Images.BACKGROUND_HEIGHT - RECT_HEIGHT, secondWidth, RECT_HEIGHT);

        drawRedDot(g2d, secondRectPos + secondWidth / 2, Images.BACKGROUND_HEIGHT - RECT_HEIGHT);

    }

    private void drawRedDot(Graphics2D g2d, int x, int y) {
        g2d.setColor(Color.RED);
        int dotSize = 5;
        int dotX = x - dotSize / 2;
        int dotY = y;
        g2d.fillOval(dotX, dotY, dotSize, dotSize);
    }
}
