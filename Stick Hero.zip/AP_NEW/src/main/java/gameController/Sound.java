package gameController;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;

public class Sound {
    private Clip clip;
    private boolean isEnabled;

    public Sound(String soundPath) {
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(soundPath));
            clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            isEnabled = true;
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
            isEnabled = false;
        }
    }

    public void play() {
        if (isEnabled) {
            clip.setFramePosition(0);
            clip.start();
        }
    }

    public void toggle() {
        isEnabled = !isEnabled;
    }

    public boolean isEnabled() {
        return isEnabled;
    }
}
