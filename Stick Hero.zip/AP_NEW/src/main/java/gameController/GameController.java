package gameController;

import gameEngine.GameEngine;
//import gamePanel.BasePanel;
import gamePanel.GamePanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.SwingUtilities;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;

public class GameController implements MouseListener, ActionListener {
    public static final int framePerSec = 80;
    private GameEngine engine;
    private GamePanel panel;
    private boolean isIncreasing;
    private boolean isRunning;
    private boolean isGameOver;
    public boolean upsideDown;

    private boolean isSoundEnabled;

    private class SoundPlayer {
        private void playSound(String soundPath) {
            if (isSoundEnabled) {
                try {
                    AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(soundPath));
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioInputStream);
                    clip.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        public void playGameOverSound() {
            playSound("C:\\Users\\Gautam Kumar\\Downloads\\mixkit-failure-arcade-alert-notification-240.wav");
        }

        public void playEatSound() {
            playSound("C:\\JAVA\\AP_PROJECT2\\AP_NEW\\Sounds\\eat.wav");
        }

        public void playScoreSound() {
            playSound("C:\\Users\\Gautam Kumar\\OneDrive\\Desktop\\sound\\score.ogg");
        }
    }

    private SoundPlayer soundPlayer;

    public GameController() {
        this.soundPlayer = new SoundPlayer();
    }

    public void init(GameEngine engine, GamePanel panel) {
        this.engine = engine;
        this.panel = panel;
    }

    private void playSound(String soundPath) {
        soundPlayer.playSound(soundPath);
    }

    public void start() {
        Thread gameLoop = new Thread(() -> {
            isRunning = true;
            while (isRunning) {
                SwingUtilities.invokeLater(() -> panel.repaint());
                try {
                    Thread.sleep(1000 / GameController.framePerSec);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        gameLoop.start();
    }

    private void playGameOverSound() {
        playSound("C:\\Users\\Gautam Kumar\\Downloads\\mixkit-failure-arcade-alert-notification-240.wav");
    }

    public void playEatSound() {
        playSound("C:\\JAVA\\AP_PROJECT2\\AP_NEW\\Sounds\\eat.wav");
    }

    private void playScoreSound() {
        playSound("C:\\Users\\Gautam Kumar\\OneDrive\\Desktop\\sound\\score.ogg");
    }



    public void enableSound() {
        isSoundEnabled = true;
    }

    public void disableSound() {
        isSoundEnabled = false;
    }

    public void goToGame() {
        panel.goToGame();
    }

    public void nextRect(boolean isMushroomEaten) {
        if (isMushroomEaten)
            engine.fruitEaten();
        engine.nextRectangle();
    }

    public void gameOver() {
        isGameOver = true;
        panel.gameOver();
        playGameOverSound();
    }

    public void replay() {
        engine.init();
        isGameOver = false;
        panel.replay(engine, this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        SwingUtilities.invokeLater(() -> {
            if (isGameOver) {
                panel.goToStart();
            } else {
                panel.goToGame();
            }
        });
        if (isIncreasing) {
            playScoreSound();
        }
    }

    public boolean isUpsideDown() {
        return upsideDown;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        SwingUtilities.invokeLater(() -> upsideDown = !upsideDown);
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (engine.isMoving()) {
            return;
        }

        Thread increaseStick = new Thread(() -> {
            isIncreasing = true;
            while (isIncreasing) {
                engine.increaseStickLength();
                try {
                    Thread.sleep(1000 / GameController.framePerSec);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
                SwingUtilities.invokeLater(() -> panel.repaint());
            }
            playScoreSound();
        });
        increaseStick.start();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        isIncreasing = false;
        engine.setMoving(true);
        engine.checkForGameOver();
        SwingUtilities.invokeLater(() -> panel.repaint());
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
