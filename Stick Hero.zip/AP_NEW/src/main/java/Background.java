import javax.swing.*;
import java.awt.*;
import java.util.concurrent.TimeUnit;

public class Background extends JPanel implements Runnable {
    private String[] imageP;
    private int currentImageIndex;
    private boolean isRunning;

    public Background(String[] imageP) {
        this.imageP = imageP;
        this.currentImageIndex = 0;
        this.isRunning = true;
        Thread thread = new Thread(this);
        thread.start();
    }

    public void stop() {
        isRunning = false;
    }

    @Override
    public void run() {
        while (isRunning) {
            try {
                TimeUnit.SECONDS.sleep(5);
                currentImageIndex = (currentImageIndex + 1) % imageP.length;
                repaint();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        try {
            Image background = new ImageIcon(imageP[currentImageIndex]).getImage();

            int x = (getWidth() - background.getWidth(this)) / 2;
            int y = (getHeight() - background.getHeight(this)) / 2;

            g.drawImage(background, x, y, this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
