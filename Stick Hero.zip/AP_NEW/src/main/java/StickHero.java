import gameController.GameController;
import gameEngine.GameEngine;
import gamePanel.GamePanel;
import java.awt.Dimension;


import javax.swing.*;

public class StickHero {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Stick Hero");

        String name = "Player";

        GameEngine engine = new GameEngine(name);

        GameController controller = new GameController();
        GamePanel panel = new GamePanel();

        engine.init();
        controller.init(engine, panel);
        panel.init(engine, controller);

        controller.start();

        frame.getContentPane().add(panel);

        panel.setPreferredSize(new Dimension(500, 600));

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setResizable(false);
    }
}